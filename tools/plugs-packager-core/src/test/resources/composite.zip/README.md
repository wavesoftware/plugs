Composite zip
-----------

Contents
